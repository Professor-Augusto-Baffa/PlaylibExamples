#include "Graphics.h"

Graphics graphics;

void MainLoop(void){
}

int main (void)
{
	graphics.CreateMainWindow(800, 600, "Projeto Exemplo");
	
	graphics.SetBackgroundColor(255,255,255);
	graphics.SetMainLoop(MainLoop);
	graphics.StartMainLoop();

	return 0;
}
